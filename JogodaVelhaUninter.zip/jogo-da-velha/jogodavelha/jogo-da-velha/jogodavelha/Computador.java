package jogodavelha;


public abstract class Computador {
                                                      //definindo tela padrão
    public abstract void jogar(String mapa[][]);
}
