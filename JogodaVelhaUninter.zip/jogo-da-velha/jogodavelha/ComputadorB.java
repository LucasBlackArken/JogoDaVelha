package jogodavelha;



import java.util.Random;

public class ComputadorB extends Computador{
    Random numeroAleatorio = new Random();
    
    @Override
    public void jogar(String[][] tab) {
                                                    //Posi��o aleat�ria de posi��o
        int x,y;
        while(true){
            x = numeroAleatorio.nextInt(3);
            y = numeroAleatorio.nextInt(3);
            if(tab[x][y].equals(" ")){
                tab [x][y] = "O";
                return;
            }
            
        }
    }

}
