package jogodavelha;

import java.util.Random;


public class ComputadorC extends Computador{

    Random numeroAleatorio = new Random();
    @Override
    public void jogar(String[][] tab) {
        //Computador tenta impedir a vitoria do jogador
        //Marca��o aleat�ria
        for(int i = 0; i < 3; i++){
            for(int j = 0; j < 3; j++){
                if(tab[i][j].equals("X")){
                    //Marcar horizontais, caso ainda n�o tenha sido feito
                    try{
                        if(tab [i+1][j].equals(" ")){
                            tab [i+1][j] = "O";
                            return;
                        }
                    }catch(Exception e){
                        
                    }
                    try{
                        if(tab [i-1][j].equals(" ")){
                            tab [i-1][j] = "O";
                            return;
                        }
                    }catch(Exception e){
                        
                    }
                    
                    //Marcar verticais, caso ainda n�o tenha sido feito
                    try{
                        if(tab [i][j+1].equals(" ")){
                            tab [i][j+1] = "O";
                            return;
                        }
                    }catch(Exception e){
                        
                    }
                    try{
                        if(tab [i][j-1].equals(" ")){
                            tab [i][j-1] = "O";
                            return;
                        }
                    }catch(Exception e){
                        
                    }
                        
                     
                    
                }
            }
        }
        //Se o modelo falhar acimar falhar, usa-se de aleatoriedade 
        int x;
        while(true){
            x = numeroAleatorio.nextInt(3);
            for(int j = 0; j < 3; j++){
                if(tab [x][j].equals(" ")){
                    tab [x][j] = "O";
                    return;
                }
            }
        }
    }

}
