package jogodavelha;


public class ComputadorA extends Computador{
    @Override
    public void jogar(String tab[][]){
        //Verifica��o de espa�o 
        for(int i = 0; i < 3; i++){
            for(int j = 0; j < 3; j++){
                if(tab [i][j].equals(" ")){
                    tab [i][j] = "O";
                    return;
                }
            }
        }
    }

    
}
