package jogodavelha;


public class Jogador {
    
    public boolean jogar(String mapa[][], String horizontal, String vertical){
        //verificar se posi��o est� ocupada, se n�o marcar X
        try{
            //transformando os dados que foram inseridos pelo jogadores e usar como indice 
            int x = Integer.parseInt(horizontal);
            int y = Integer.parseInt(vertical);
            if (mapa[x-1][y-1].equals(" ")){
                mapa[x-1][y-1] = "X";
                return true;
            }else{
                //Posi��o ocupada
                System.out.println("Posi��o j� ocupada");
                return false;
            }
        }catch(Exception e){
            System.out.println("Valor Errado");
            return false;
        }
                    
    }
}
