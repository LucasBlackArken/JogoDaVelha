package jogodavelha;


public abstract class Computador {
                                                                  //Defini��o Padr�o
    public abstract void jogar(String tab [][]);
}
